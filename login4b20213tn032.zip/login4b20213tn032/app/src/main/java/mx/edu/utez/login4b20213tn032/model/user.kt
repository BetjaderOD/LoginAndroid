package mx.edu.utez.login4b20213tn032.model

import com.google.firebase.database.IgnoreExtraProperties


@IgnoreExtraProperties
data class User (var  uname: String?=null, var lastname: String?=null, var fecNac: String?=null)


