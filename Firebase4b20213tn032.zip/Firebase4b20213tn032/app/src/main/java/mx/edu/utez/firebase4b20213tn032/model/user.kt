package mx.edu.utez.firebase4b20213tn032.model

import com.google.firebase.database.IgnoreExtraProperties


@IgnoreExtraProperties
data class User (var  username: String?=null, var email: String?=null, var year: Double?=null)
