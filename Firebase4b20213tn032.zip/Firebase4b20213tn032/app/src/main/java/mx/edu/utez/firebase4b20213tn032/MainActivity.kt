package mx.edu.utez.firebase4b20213tn032

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import mx.edu.utez.firebase4b20213tn032.databinding.ActivityMainBinding
import mx.edu.utez.firebase4b20213tn032.model.User

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    private lateinit var database : DatabaseReference
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
     binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        database = Firebase.database.reference

        writeNewUser("ac124", "Messi", "messi@gmail.com",1987.0)

        database.child("users").child("abc02").get().addOnSuccessListener {
            Log.i("firebase", "Got value ${it.value.toString()}")
        }.addOnFailureListener {
            Log.e("firebase", "Error getting data", it)
        }

        var query = database.child("users").orderByChild("year")
            .startAt(1980.0).endAt(2000.0)
        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (issue in dataSnapshot.children) {
                        Log.e("LOG??", issue.toString())
                    }
                }
            }
            override fun onCancelled(databaseError: DatabaseError) {
            }
        })
        var usuario = mapOf(
            "email" to "messi@gmail.com",
            "username" to "betja"
        )
        database.child("users").child("abc02").updateChildren(usuario)

        database.child("users").child("abc02").removeValue()
    }



    fun writeNewUser(userId: String, name: String, email: String, year: Double) {
        val user = User(name, email, year)
        database.child("users").child(userId).setValue(user)
    }


}